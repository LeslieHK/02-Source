package com.servlet;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class EncodingServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
		
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		// ���GET�ύ������
		String username = request.getParameter("username");
		String truename = request.getParameter("truename");

		//System.out.println("get_username = " + username);
		//System.out.println("get_truename = " + truename);
		
		//1��������
		//username = new String(username.getBytes("ISO-8859-1"), "UTF-8");	
		//truename = new String(truename.getBytes("ISO-8859-1"),"UTF-8");
		
		System.out.println("get_username = " + username);
		System.out.println("get_truename = " + truename);
		
		//2��Ӳ��������÷�ʽ����GET�ύ�����Ĳ������á�
		
		//3������Tomcat��Server.xml�е����á�URIEncoding="UTF-8"
		
		out.flush();
		out.close();
	}

}
