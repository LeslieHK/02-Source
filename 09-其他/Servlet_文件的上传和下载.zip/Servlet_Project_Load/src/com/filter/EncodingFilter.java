package com.filter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 */

/**
 * @author Administrator
 *
 */
public class EncodingFilter implements Filter {

	public void destroy() {

	}

	public void doFilter(ServletRequest req, ServletResponse res,
			FilterChain chain) throws IOException, ServletException {

		HttpServletRequest request = (HttpServletRequest)req;
		HttpServletResponse response = (HttpServletResponse)res;
		
		// ���POST����
		request.setCharacterEncoding("UTF-8");
		//��GET��������һ��ת��Ĵ���
		String method = request.getMethod();
		if(method != null && method.equals("GET")){
				req = new GetConvert(request);
		}
		response.setCharacterEncoding("UTF-8");
		
		chain.doFilter(req, res);
	}

	public void init(FilterConfig arg0) throws ServletException {
		
	}

	class GetConvert extends HttpServletRequestWrapper{

		public GetConvert(HttpServletRequest request) {
			super(request);
		}
		@Override
		public String getParameter(String name) {
			String value = super.getParameter(name);
			if(value != null && !value.equals("")){
				try {
					value = new String(value.getBytes("ISO-8859-1"),"UTF-8");
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				}
			}
			return value;
		}
		
	}
	
}
