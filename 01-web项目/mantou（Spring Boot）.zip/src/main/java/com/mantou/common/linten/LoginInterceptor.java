package com.mantou.common.linten;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by wuweiliang on 2017/4/19.
 */
public class LoginInterceptor extends HandlerInterceptorAdapter {
    private static final Logger logger = LoggerFactory.getLogger(LoginInterceptor.class);

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        logger.warn("=====================开始拦截====================");
        String uri = request.getRequestURL().toString();
        String referer = request.getHeader("Referer");
        logger.warn("=====================:"+referer);
        logger.warn("=====================:"+uri);
        logger.warn("=====================拦截结束====================");
        String acceptHeader = request.getHeader("X-Requested-With");
        String path = request.getContextPath();
        String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path;
        if (!StringUtils.isEmpty(acceptHeader) && "XMLHttpRequest".equals(acceptHeader)) {
            logger.warn("=====================:ajax");
           // request.getRequestDispatcher("/route/hello").forward(request,response);
            //response.sendRedirect(basePath + "/page/hello.html");
            try {
                response.setContentType("text/html;charset=utf-8");
                response.sendRedirect(basePath + "/page/hello.html");
            } catch (IOException e) {
                logger.warn("==============异常开始=============");
                logger.error("跳转失败:",e);
            }
        } else {
            logger.warn("=====================:no ajax");
            //response.sendRedirect(basePath + "/page/index.html");
//            request.getRequestDispatcher("/route/hello").forward(request,response);
            try {
                response.setContentType("text/html;charset=utf-8");
                response.sendRedirect(basePath + "/page/hello.html");
            } catch (IOException e) {
                logger.warn("==============异常开始=============");
                logger.error("跳转失败:",e);
            }
        }
        return true;
    }
}
