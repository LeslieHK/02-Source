package com.mantou.server.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by wuweiliang on 2017/4/22.
 */
@Controller
@RequestMapping(value = "/route")
public class RouteController extends BaseController {
    private Logger logger = LoggerFactory.getLogger(RouteController.class);

    @RequestMapping(value = "/error",method = RequestMethod.GET)
    public void error(HttpServletRequest request, HttpServletResponse response){
        String path = request.getContextPath();
        String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path;
        try {
            response.sendRedirect(basePath + "/yangquan/xyquan.html#/wdsbym");
        } catch (IOException e) {
            logger.warn("==============异常开始=============");
            logger.error("跳转失败:",e);
        }
    }

    @RequestMapping(value = "/hello",method = RequestMethod.GET)
    public void test(HttpServletRequest request, HttpServletResponse response){
        String path = request.getContextPath();
        String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path;
        try {
            response.sendRedirect(basePath + "/page/hello.html");
        } catch (IOException e) {
            logger.warn("==============异常开始=============");
            logger.error("跳转失败:",e);
        }
    }

    @RequestMapping(value = "/index",method = RequestMethod.GET)
    public void toindex(HttpServletRequest request, HttpServletResponse response){
        String path = request.getContextPath();
        String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path;
        try {
            response.setContentType("text/html;charset=utf-8");
            response.sendRedirect(basePath + "/yangquan/xyquan.html");
        } catch (IOException e) {
            logger.warn("==============异常开始=============");
            logger.error("跳转失败:",e);
        }
    }

//    @RequestMapping(value = "/xyquan",method = RequestMethod.GET)
//    public void create(HttpServletRequest request, HttpServletResponse response){
//        String path = request.getContextPath();
//        String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path;
//        try {
//            response.sendRedirect(basePath + "/yangquan/xyquan.html");
//        } catch (IOException e) {
//            logger.warn("==============异常开始=============");
//            logger.error("跳转失败:",e);
//        }
//    }

    @RequestMapping(value = "/list",method = RequestMethod.GET)
    public void tolist(HttpServletRequest request,HttpServletResponse response){
        String path = request.getContextPath();
        String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path;
        try {
            response.setContentType("text/html;charset=utf-8");
            response.sendRedirect(basePath + "/yangquan/xyquan.html#/wdsbym");
        } catch (IOException e) {
            logger.warn("==============异常开始=============");
            logger.error("跳转失败:",e);
        }
    }
}
