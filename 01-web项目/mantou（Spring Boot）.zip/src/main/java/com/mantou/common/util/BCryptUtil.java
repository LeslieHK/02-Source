package com.mantou.common.util;

import org.springframework.security.crypto.bcrypt.BCrypt;

import java.security.SecureRandom;

/**
 * Created by wuweiliang on 2017/4/20.
 */
public class BCryptUtil {


    public static void main(String[] args) {
        String pw_hash = BCrypt.hashpw("sdfklsad", BCrypt.gensalt(10,new SecureRandom("12364".getBytes())));
//        boolean pw_hash = BCrypt.checkpw("isc123456","$2y$10$yzzm7M77bjoC4JYptz9iyugSQ7NVy5/dSNa4cmEQ1dxt6SE/K1w2m");
        System.out.println(pw_hash);

    }
}
