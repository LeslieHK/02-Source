package com.mantou.common;

/**
 * Created by wuweiliang on 2017/4/19.
 */
public class Constants {
    //公众号accesstoken存在数据库的键名
    public final static String ACCESS_TOKEN_KEY = "RaiseDogAccessToken";
}
