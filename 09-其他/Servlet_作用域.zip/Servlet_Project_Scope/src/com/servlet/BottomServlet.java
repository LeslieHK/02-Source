package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bean.userBean;

public class BottomServlet extends HttpServlet {


	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		doPost(request, response);
		
		out.flush();
		out.close();
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		HttpSession session = request.getSession();
		userBean bean = (userBean) session.getAttribute("bean");
		
		String userid = bean.getUserid();
		String username = bean.getUsername();
		
		out.println("<style type=\"text/css\">");
		out.println("	body {");
		out.println("		margin-left: 0px;");
		out.println("		margin-top: 0px;");
		out.println("		margin-right: 0px;");
		out.println("		margin-bottom: 0px;");
		out.println("		font-size:12px;");
		out.println("	}");
		out.println("</style></head>");
		out.println("<body>");
		out.println("	<table width=\"100%\" border=\"0\">");
		out.println("		<tr>");
		out.println("			<td>�Ñ���:" + username + "</td>");
		out.println("			<td>�Ñ�ID:" + userid + "</td>");
		out.println("			<td>��¼ʱ�䣺2014-07-07 21��22</td>");
		out.println("			<td>����֧�֣�XXX��˾����</td>");
		out.println("			<td>��ϵ�绰��1234567</td>");
		out.println("		</tr>");
		out.println("	</table>");
		out.println("</body>");
		
		out.flush();
		out.close();
	}

}
