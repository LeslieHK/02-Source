package com.servlet;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.jms.Session;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bean.userBean;

public class LoginServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
		
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		//��ȡ�û����������ֵ
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		String filePath = this.getServletContext().getRealPath("/user.data");
		
		BufferedReader reader = new BufferedReader(new FileReader(filePath));
		
		String line = null;
		userBean userBean = null;
		List<userBean> userList = new ArrayList<userBean>();
		
		while ((line = reader.readLine()) != null) {
			if (line != null && !line.equals("")) {
				String[] strArray = line.split(",");
				if (strArray != null && strArray.length > 0) {
					userBean = new userBean();
					userBean.setUserid(String.valueOf(strArray[0]));
					userBean.setUsername(String.valueOf(strArray[1]));
					userBean.setPassword(String.valueOf(strArray[2]));
					userBean.setBirthday(String.valueOf(strArray[3]));

					userList.add(userBean);
				}
			}
		}
		
		boolean exit = false;
		HttpSession session = request.getSession();
		int errorCnt = 0;
		
		if(session.getAttribute("errorCnt") == null){
			session.setAttribute("errorCnt", 0);
		}
		errorCnt = (Integer) session.getAttribute("errorCnt");
		
		for(userBean bean : userList){
			String text_username = bean.getUsername();
			String text_password = bean.getPassword();
			
			if(text_username.equals(username)){
				//�Д��ܴa
				if(text_password.equals(password)){
					session.setAttribute("bean", bean);
					String mainURL = request.getContextPath() + "/main.jsp";
					response.sendRedirect(mainURL);
				} else{
					errorCnt ++;
					session.setAttribute("errorCnt", errorCnt);
					
					if(errorCnt >= 3){
						out.println("<script language='javascript'>");
						out.println("window.alert('�ܴa���e���^3�Σ������P�]');");
						out.println("window.opener = null;");
						out.println("window.close();");
						out.println("</script>");
					} else{
						int diffCnt = 3 - errorCnt;
						out.println("<script language='javascript'>");
						out.println("window.alert('�ܴa�e�`��߀��" + diffCnt +"')");
						out.println("window.history.back();");
						out.println("</script>");
					}
				}
				exit = true;
				break;
			}	
		}

		if(exit == false){
			out.println("<script language='javascript'>");
			out.println("	window.alert('�û��������ڣ����������');");
			out.println("	window.history.back();");
			out.println("</script>");
		}
		
		out.flush();
		out.close();
	}

}
