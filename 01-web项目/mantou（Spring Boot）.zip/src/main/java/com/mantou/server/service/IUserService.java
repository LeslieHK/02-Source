package com.mantou.server.service;

import com.mantou.server.entity.Result;

/**
 * Created by wuweiliang on 2017/4/18.
 */
public interface IUserService {
    Result show(String id);
}
