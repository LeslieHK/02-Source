package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.bean.*;

public class ScopeRequest_Result extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		doPost(request, response);
		
		out.flush();
		out.close();
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		//����������ȡ����
		Object obj_1 = request.getAttribute("userList");
		Object obj_2 = request.getAttribute("str");
		Object obj_3 = request.getAttribute("systime");
		
		out.println("<table border='1' width='100%'>");
		out.println("	<tr>");
		out.println("		<td>�û����</td>");
		out.println("		<td>�û���</td>");
		out.println("		<td>����</td>");
		out.println("		<td>��������</td>");
		out.println("	</tr>");
		List<userBean> userList = (List<userBean>) obj_1;
		for (userBean userbean : userList) {
			String userid = userbean.getUserid();
			String username = userbean.getUsername();
			String password = userbean.getPassword();
			String birthday = userbean.getBirthday();

			out.println("<tr>");
			out.println("	<td>" + userid + "</td>");
			out.println("	<td>" + username + "</td>");
			out.println("	<td>" + password + "</td>");
			out.println("	<td>" + birthday + "</td>");
			out.println("</tr>");
		}
		out.println("</table>");
		
		out.println("<br /><br />");
		out.println("str = " + obj_2);
		out.println("<br /><br />");
		out.println("systime = " + obj_3);
		
		out.flush();
		out.close();
	}

}
