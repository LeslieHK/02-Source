package com.servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DownloadServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		this.doPost(request, response);
		
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");

		String filepath = request.getParameter("filepath");
		
		ServletContext context = this.getServletContext();
		String uploadpath = context.getRealPath("/uploadfiles");

		File file = new File(uploadpath);
		File[] listFileArray = file.listFiles();
		InputStream inputstream = null;
		ServletOutputStream outputstream = null;
		for(File tempFile : listFileArray){
			String txt_filepath = tempFile.getName();
			if(txt_filepath.equals(filepath)){
				inputstream = new FileInputStream(tempFile);
				
				filepath = new String(filepath.getBytes("GBK"), "ISO-8859-1");
				
				// response.setHeader("Content-type", "application/x-msdownload");
				response.setContentType("application/x-msdownload");
				response.setHeader("Content-disposition", "attachment;filename="
						+ filepath + "");
				
				outputstream = response.getOutputStream();
				int i = 0;
				byte[] b = new byte[10240];
				while((i = inputstream.read(b)) != -1){
					outputstream.write(b);
				}
				outputstream.flush();
				break;
			}

		}
		// �ر���������
		if (inputstream != null) {
			inputstream.close();
			inputstream = null;
		}
		if (outputstream != null) {
			outputstream.close();
			outputstream = null;
		}

	}

}
