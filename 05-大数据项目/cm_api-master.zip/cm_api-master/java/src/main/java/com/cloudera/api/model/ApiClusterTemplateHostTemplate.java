// Licensed to Cloudera, Inc. under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  Cloudera, Inc. licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package com.cloudera.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.google.common.collect.Lists;

import java.util.List;

/**
 * Host templates will contain information about the role config groups that
 * should be applied to a host. This basically means a host will have a role
 * corresponding to each config group.
 */
@JsonInclude(Include.NON_EMPTY)
public class ApiClusterTemplateHostTemplate {
  /**
   * Reference name
   */
  private String refName;
  /**
   * Represent the cardinality of this host template on source
   */
  private int cardinality;
  /**
   * List of role config groups
   */
  private List<String> roleConfigGroupsRefNames = Lists.newArrayList();

  public String getRefName() {
    return this.refName;
  }

  public void setRefName(String refName) {
    this.refName = refName;
  }

  public List<String> getRoleConfigGroupsRefNames() {
    return this.roleConfigGroupsRefNames;
  }

  public void setRoleConfigGroupsRefNames(
      List<String> roleConfigGroupsRefNames) {
    this.roleConfigGroupsRefNames = roleConfigGroupsRefNames;
  }

  public int getCardinality() {
    return this.cardinality;
  }

  public void setCardinality(int cardinality) {
    this.cardinality = cardinality;
  }

}