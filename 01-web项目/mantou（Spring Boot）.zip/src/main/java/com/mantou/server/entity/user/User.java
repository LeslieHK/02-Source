package com.mantou.server.entity.user;

import lombok.Getter;
import lombok.Setter;

/**
 * Created by wuweiliang on 2017/4/17.
 */
@Getter
@Setter
public class User {
    private String id;//
    private String name;//
    private String nickname;//
    private String password;//
}
