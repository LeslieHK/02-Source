package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class TestInclude_Result extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		String id = request.getParameter("id");
		String name = request.getParameter("name");

		out.println("������������--ҳ���ͷ�����ߵײ���һЩ���õ���Ϣ<br/>");

		out.println("<HTML>");
		out.println("  <BODY");
		out.println("	<table border='1' width='100%'>");
		out.println("		<tr>");
		out.println("			<td>�汾��Ϣ��</td>");
		out.println("		</tr>");
		out.println("		<tr>");
		out.println("			<td>id=" + id + "&nbsp;&nbsp;&nbsp;Name = " + name + "</td>");
		out.println("		</tr>");
		out.println("	</table>");
		out.println("  </BODY>");
		out.println("</HTML>");
		
		out.flush();
		out.close();
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.flush();
		out.close();
	}

}
