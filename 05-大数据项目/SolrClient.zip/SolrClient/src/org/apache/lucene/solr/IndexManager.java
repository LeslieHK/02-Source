package org.apache.lucene.solr;

import org.apache.solr.client.solrj.impl.HttpSolrServer;
import org.apache.solr.common.SolrInputDocument;
import org.junit.Test;

public class IndexManager {

	@Test
	/**
	 * ����
	 * @throws Exception
	 */
	public void insertAndUpdateIndex() throws Exception {
		HttpSolrServer server = new HttpSolrServer("http://localhost:8080/solr");

		SolrInputDocument doc = new SolrInputDocument();
		doc.addField("id", "c001");
		doc.addField("name", "solr test");
		
		server.add(doc);
		server.commit();
	}
	
	@Test
	/**
	 * ����IDɾ��
	 * @throws Exception
	 */
	public void deleteIndexById() throws Exception {
		HttpSolrServer server = new HttpSolrServer("http://localhost:8080/solr");
		server.deleteById("c001");
		
		server.commit();
	}
	
	@Test
	/**
	 * ��������ɾ��
	 * @throws Exception
	 */
	public void deleteIndexByCondition() throws Exception {
		HttpSolrServer server = new HttpSolrServer("http://localhost:8080/solr");
		server.deleteByQuery("id:c001");
		// ȫ��ɾ��������
		// server.deleteByQuery("*:*");
		
		server.commit();
	}
}
