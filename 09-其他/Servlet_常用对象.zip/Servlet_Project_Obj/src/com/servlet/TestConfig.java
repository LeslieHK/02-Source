package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class TestConfig extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		//��ȡConfig����
		ServletConfig config = this.getServletConfig();
		
		//��ȡweb.xml��<servlet-name>TestConfig</servlet-name>�е�����
		String servletName = config.getServletName();
		out.println("servletName��ֵ = " + servletName);
		out.println("<br /><br />");
		
		//getInitParameter();�Ƕ�ȡservlet�������õ�init-param�Ĳ�����Ϣ
		String value_i = config.getInitParameter("config_i");
		out.println("confit_i�Ĳ���ֵ = " + value_i);
		out.println("<br /><br />");
		String value_j = config.getInitParameter("config_j");
		out.println("confit_j�Ĳ���ֵ = " + value_j);
		out.println("<br /><br />");
		String value_k = config.getInitParameter("config_k");
		out.println("config_k�Ĳ���ֵ = " + value_k);
		out.println("<br /><br />");
		
		//getInitParameterNames();
		Enumeration enumration = config.getInitParameterNames();
		while(enumration.hasMoreElements()){
			String param_name = (String) enumration.nextElement();
			String param_value = config.getInitParameter(param_name);
			out.println("������ = " + param_name + "&nbsp;&nbsp;����ֵ = " + param_value);
			out.println("<br /><br />");
		}
		
		//��ȡServletContext����
		ServletContext context = config.getServletContext();
		
		out.flush();
		out.close();
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.flush();
		out.close();
	}

}
