package com.servlet;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.util.DateUtil;



public class UploadServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		this.doPost(request, response);
		
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		String task = request.getParameter("task");
		ServletContext context = this.getServletContext();
		String uploadpath = context.getRealPath("/uploadfiles");
		
		if(task.equals("add")){
			
			request.getRequestDispatcher("/upload_add.jsp").forward(request, response);
		
		} else if(task.equals("save")){
			// ����ʹ��Request.getParameter����ȡ�ͻ��ύ�Ķ�������������
			// String product_name = request.getParameter("product_name");
			// String product_price = request.getParameter("product_price");
			// System.out.println(product_name);
			// System.out.println(product_price);

			// ԭʼ��Request���е�����
			// InputStream inputStream = request.getInputStream();
			// int i = 0;
			// while((i = inputStream.read()) != -1){
			// System.out.print((char)i);
			// }

			// ������������jar����
			boolean flag = false;
			String errorMsg = null;
			DiskFileItemFactory factory = new DiskFileItemFactory();
			ServletFileUpload fileUpload = new ServletFileUpload(factory);
			
			try {
				List<FileItem> itemList = fileUpload.parseRequest(request);
				Map<String, String> dataMap = new HashMap<String, String>();
				
				for(int i = 0;i <itemList.size();i ++){
					FileItem fileitem = itemList.get(i);
					//System.out.println(fileitem);
					
					boolean isFormField = fileitem.isFormField();
					if(isFormField == true){
						// ��ʾ�������ı���Ԫ��
						String fileName = fileitem.getFieldName();
						String fileValue = fileitem.getString("UTF-8");
						dataMap.put(fileName, fileValue);
					} else{
						// ��ʾ���ļ���������ļ����ϴ�
						String filename = fileitem.getName();
						String filepath = null;
						if(filename != null && filename != ""){
							filename = filename.substring(filename.lastIndexOf("\\") + 1);
							filepath = DateUtil.getTimeStamp() + "_" + filename;
							dataMap.put("filename", filename);
							dataMap.put("filepath", filepath);
							
							InputStream inputstream = fileitem.getInputStream();
							OutputStream outputstream = new FileOutputStream(uploadpath + "/" + filepath);
							
							// ��ʼ�����ݵĴ���
							int j = 0;
							byte[] b = new byte[10240];
							while((j = inputstream.read(b)) != -1){
								outputstream.write(b, 1, j);
							}
							outputstream.flush();
							
							//�ر���
							if(inputstream != null){
								inputstream.close();
								inputstream = null;
							}
							if(outputstream != null){
								outputstream.close();
								outputstream = null;
							}
						}

					}
					
				}
				// ���հ�����д�뵽�ļ��С�

				System.out.println(dataMap);
				String product_name = dataMap.get("product_name");
				String product_price = dataMap.get("product_price");
				String filename = dataMap.get("filename");
				String filepath = dataMap.get("filepath");

				System.out.println("product_name = " + product_name);
				System.out.println("product_price = " + product_price);
				System.out.println("filename = " + filename);
				System.out.println("filepath = " + filepath);
				flag = true;
			} catch (FileUploadException e) {
				e.printStackTrace();
				errorMsg = e.getMessage().trim();
				flag = false;
			}
			if (flag == true) {
				String listURL = request.getContextPath() + "/servlet/UploadServlet?task=list";
				out.println("<script language='javascript'>");
				out.println("window.alert('�ϴ��ɹ�!���ȷ����Ŧ,���ص������б�ҳ��');");
				out.println("window.location.href = '" + listURL + "';");
				out.println("</script>");
			} else {
				out.println("<script language='javascript'>");
				out.println("window.alert('�ϴ�ʧ��!ԭ�� ��" + errorMsg + "' );");
				out.println("window.history.back();");
				out.println("</script>");
			}
			
		} else if(task.equals("list")){
			List<Map<String, String>> fileList = new ArrayList<Map<String,String>>();
			File file = new File(uploadpath);
			File[] listFileArray = file.listFiles();
			int fileno = 0;
			Map<String, String> map = null;
			for(File tempFile : listFileArray){
				fileno ++;
				String filepath = tempFile.getName();
				String filename = null;
				if(filepath != null){
					String[] strArray = filepath.split("_");
					if(strArray.length == 2){
						filename = strArray[1];
					}
				}
				map = new HashMap<String, String>();
				map.put("fileno", String.valueOf(fileno));
				map.put("filepath", filepath);
				map.put("filename", filename);
				
				fileList.add(map);
			}
			request.setAttribute("fileList", fileList);
			request.getRequestDispatcher("/upload_list.jsp").forward(request, response);

		}
		
		out.flush();
		out.close();
	}

}
