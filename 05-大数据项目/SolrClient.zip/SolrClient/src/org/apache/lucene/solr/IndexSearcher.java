package org.apache.lucene.solr;

import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrQuery.ORDER;
import org.apache.solr.client.solrj.impl.HttpSolrServer;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.junit.Test;

public class IndexSearcher {

	@Test
	/**
	 * �򵥲�ѯ
	 * @throws Exception
	 */
	public void simpleIndexSearcher() throws Exception {
		
		HttpSolrServer server = new HttpSolrServer("http://localhost:8080/solr");
		
		SolrQuery query = new SolrQuery();
		query.setQuery("product_name:С����");
		
		QueryResponse response = server.query(query);
		SolrDocumentList results = response.getResults();
		System.out.println(results.getNumFound());
		
		for(SolrDocument sd : results){
			System.out.println(sd.get("id"));
			System.out.println(sd.get("product_name"));
			System.out.println(sd.get("product_price"));
			System.out.println(sd.get("product_catalog"));
			System.out.println(sd.get("product_catalog_name"));
			System.out.println(sd.get("product_picture"));
			System.out.println("============================");
		}
	}
	
	
	@Test
	/**
	 * ���Ӳ�ѯ
	 * @throws Exception
	 */
	public void complexIndexSearcher() throws Exception {
		
		HttpSolrServer server = new HttpSolrServer("http://localhost:8080/solr");
		
		SolrQuery query = new SolrQuery();
		query.setQuery("product_name:С����");
		query.setFilterQueries("product_price:[10 TO 10]");
		query.setSort("id", ORDER.asc);
		query.setStart(0);
		query.setRows(10);
		query.setFields("id,product_name,product_price,product_catalog,product_catalog_name,product_picture");
		query.set("df", "product_name");
		query.setHighlight(true);
		query.addHighlightField("product_name");
		query.setHighlightSimplePre("<span color='red'>");
		query.setHighlightSimplePost("</span>");
		
		QueryResponse response = server.query(query);
		SolrDocumentList results = response.getResults();
		System.out.println(results.getNumFound());
		
		for(SolrDocument sd : results){
			System.out.println(sd.get("id"));
			System.out.println(sd.get("product_name"));
			System.out.println(sd.get("product_price"));
			System.out.println(sd.get("product_catalog"));
			System.out.println(sd.get("product_catalog_name"));
			System.out.println(sd.get("product_picture"));
			System.out.println("============================");
		}
	}
}
