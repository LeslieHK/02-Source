package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class TestFormServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.flush();
		out.close();
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		//1����Request��ȡ��ʽ����
		//request.getHeader(name);request.getHeaderNames();
		Enumeration enumeration = request.getHeaderNames();
		while(enumeration.hasMoreElements()){
			String head_name = (String) enumeration.nextElement();
			String head_value = request.getHeader(head_name);
			//System.out.println(head_name + " = " + head_value);
		}
		
		//2��ʹ��Request��ȡ��ʾ����
		//request.getParameter(name);
		//request.getParameterNames();
		//request.getParameterValues(name);
		
		String username = request.getParameter("username");
		String remark = request.getParameter("remark");
		String password = request.getParameter("password");
		String usersex = request.getParameter("usersex");
		String[] likeArray = request.getParameterValues("userlike");
		String like = "";
		if(likeArray != null && likeArray.length > 1){
			for(String str : likeArray){
				like = like + "," + str;
			}
			if(like.length() > 1){
				like = like.substring(1);
			}
		}
		String province = request.getParameter("province");
		String singer = request.getParameter("singer");
		String[] listArray = request.getParameterValues("list");
		String list = "";
		if(listArray != null && listArray.length > 1){
			for(String str : listArray){
				list = list + "," + str;
			}
			if(list.length() > 1){
				list = list.substring(1);
			}
		}
		String hidden = request.getParameter("hidden");
		
		System.out.println("username = " + username);
		System.out.println("remark = " + remark);
		System.out.println("password = " + password);
		System.out.println("usersex = " + usersex);
		System.out.println("like = " + like);
		System.out.println("province = " + province);
		System.out.println("singer = " + singer);
		System.out.println("list = " + list);
		System.out.println("hidden = " + hidden);
		
		out.flush();
		out.close();
	}

}
