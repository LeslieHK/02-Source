package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sun.xml.internal.ws.resources.HttpserverMessages;

public class TestSession extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
		
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		//1������session���󲢻�ȡsession����
		HttpSession session = request.getSession();
		
		//2����ȡSessionID
		String sessionId = session.getId();

		//3����ȡ����ʱ��
		long creatTime = session.getCreationTime();
		Date date_1 = new Date(creatTime);

		//4�����һ�η���ʱ��
		long accessTime = session.getLastAccessedTime();
		Date date_2 = new Date(accessTime);
		
		//5����ȡSession����Чʱ��
		long interval = session.getMaxInactiveInterval();
		Date date_3 = new Date(interval);
		
		//6������Чʱ��,��λ����
		
		//A�����÷���
		session.setMaxInactiveInterval(30);	
		
		//B����web.xml������<session-config>

		out.println("sessionId = " + sessionId);
		out.println("<br /><br />");
		out.println("createTime = " + date_1.toLocaleString());
		out.println("<br /><br />");
		out.println("accessTime = " + date_2.toLocaleString());
		out.println("<br /><br />");
		out.println("interval = " + date_2.toLocaleString());
		
		out.flush();
		out.close();
	}

}
