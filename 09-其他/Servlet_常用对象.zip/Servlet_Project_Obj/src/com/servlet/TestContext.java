package com.servlet;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * ServletContext����
 * 
 * ��ȡServlet��WEB�����еĶ�����Ϣ
 * 
 * @author Administrator
 *
 */

public class TestContext extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		//��ȡServletConxt����
		//ServletConfig config = this.getServletConfig();
		//ServletContext context = config.getServletContext();
		ServletContext context = this.getServletContext();
		
		//��ȡWEB��������
		String contextPath = context.getContextPath();
		out.println("�������� = " + contextPath);
		out.println("<br /><br />");
		
		//��ȡ�ļ���WEB�����е���ʵ·��
		String filePath = context.getRealPath("user.txt");
		File file = new File(filePath);
		FileReader fileReader = new FileReader(file);
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		String line = null;
		if((line = bufferedReader.readLine()) != null){
			System.out.println(line);
		}
		bufferedReader.close();
		
		//��ȡ�ļ���WEB���̵���ʵ·������ת����InputStream�ĸ�ʽ
		InputStream inputStream = context.getResourceAsStream("/user.txt");
		InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
		BufferedReader reader = new BufferedReader(inputStreamReader);
		while((line = reader.readLine()) != null){
			System.out.println(line);
		}
		reader.close();
		
		//ServletConfig�е�getInitParameter()ֻ�ܻ�ȡ�����Ĳ��� 
		//String value_i = this.getServletConfig().getInitParameter("config_i");
		//ServletContext�е�getInitParameter();��ȡ����web.xml�е�ȫ�ֲ���
		String global_i = context.getInitParameter("global_i");
		out.println("global_i��ֵ = " + global_i);
		out.println("<br /><br />");
		String global_j = context.getInitParameter("global_j");
		out.println("global_j��ֵ = " + global_j);
		out.println("<br /><br />");
		String global_k = context.getInitParameter("global_k");
		out.println("global_k��ֵ = " + global_k);
		out.println("<br /><br />");
		
		//ServletConfig�е�getInitParameterNames();
		Enumeration enumeration = context.getInitParameterNames();
		while(enumeration.hasMoreElements()){
			String param_name = (String) enumeration.nextElement();
			String param_value = context.getInitParameter(param_name);
			System.out.println(param_value);
		}
		
		//ServletContext�������򷽷�
		//������������WEB�����еĴ�������Լ����ݵĴ������
		//context.setAttribute(name, object);
		//context.getAttribute(name);
		//context.removeAttribute(name);
		
		out.flush();
		out.close();
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.flush();
		out.close();
	}

}
