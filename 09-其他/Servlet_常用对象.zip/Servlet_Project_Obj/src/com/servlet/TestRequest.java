package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class TestRequest extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		//1:ʹ��Request����ȡ�������Ϣ
		String servletName = request.getServerName();
		int servletPort = request.getServerPort();
		String servletPath = request.getServletPath();
		out.println("servletName = " + servletName);
		out.println("<br /><br />");
		out.println("servletPort = " + servletPort);
		out.println("<br /><br />");
		out.println("servletPath = " + servletPath);
		out.println("<br /><br />");
		
		String localName = request.getLocalName();
		int localPort = request.getLocalPort();
		String localAddr = request.getLocalAddr();
		out.println("localName = " + localName);
		out.println("<br /><br />");
		out.println("localPort = " + localPort);
		out.println("<br /><br />");
		out.println("localAddr = " + localAddr);
		out.println("<br /><br />");
		
		//2��ʹ��Request��ȡ�ͻ�����Ϣ
		String remoteUser = request.getRemoteUser();
		int remotePort = request.getRemotePort();
		String remoteHost = request.getRemoteHost();
		String remoteAddr = request.getRemoteAddr();
		out.println("remoteUser = " + remoteUser);
		out.println("<br /><br />");
		out.println("remotePort = " + remotePort);
		out.println("<br /><br />");
		out.println("remoteHost = " + remoteHost);
		out.println("<br /><br />");
		out.println("remoteAddr = " + remoteAddr);
		out.println("<br /><br />");
		
		//3:ʹ��Request�����ȡ��ַ��Ϣ
		///Servlet_Project_2/servlet/TestRequest
		String URI = request.getRequestURI();
		//http://localhost:8081/Servlet_Project_2/servlet/TestRequest
		StringBuffer URL = request.getRequestURL();
		//��ȡWEB��������
		String contextPath = request.getContextPath();
		//��ȡ·�����ڣ���������ݣ���javascript��location����searchһ��
		String queryString = request.getQueryString();
		
		out.println("getRequestURI = " + URI);
		out.println("<br /><br />");
		out.println("getRequestURL = " + URL);
		out.println("<br /><br />");
		out.println("contextPath = " + contextPath);
		out.println("<br /><br />");
		out.println("getQueryString = " + queryString);
		out.println("<br /><br />");
		
		String finalURL = null;
		if(queryString != null && queryString.length() > 0){
			finalURL = URL + "?" + queryString;
		}
		out.println("finalURL = " + finalURL);
		
		//��ȡ��ʾ����ʽ����
		
		out.flush();
		out.close();
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.flush();
		out.close();
	}

}
