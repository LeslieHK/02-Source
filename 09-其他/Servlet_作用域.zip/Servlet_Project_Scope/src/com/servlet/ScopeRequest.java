package com.servlet;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.userBean;

/*
 * Request������
 */
public class ScopeRequest extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
		
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		// ��ȡuser.data�ļ��е����ݡ�

		// A��ֱ����Servlet�ж�ȡ��Ȼ���������

		// B����Servlet�ж�ȡ�������ݷŵ��������У�Ȼ��ת������һ��WEB�����
		
		String filePath = this.getServletContext().getRealPath("/user.data");
		BufferedReader reader = new BufferedReader(new FileReader(filePath));
		
		String line = null;
		userBean userbean = null;
		List<userBean> userList = new ArrayList<userBean>();
		
		while((line = reader.readLine()) != null){
			if(line != null && line != ""){
				String[] strArray = line.split(",");
				if(strArray != null && strArray.length > 0){
					userbean = new userBean();
					userbean.setUserid(strArray[0]);
					userbean.setUsername(strArray[1]);
					userbean.setPassword(strArray[2]);
					userbean.setBirthday(strArray[3]);
				}				
				userList.add(userbean);
			}			
		}
		
		//�ŵ�Request��������
		request.setAttribute("userList", userList);
		request.setAttribute("str", "�����ַ���");
		request.setAttribute("systime", new Date());
		
		//����ת�����ض�����һ��ҳ��
		//String redirect_url = request.getContextPath() + "/servlet/ScopeRequest_Result";
		//response.sendRedirect(redirect_url);
		
		String dispatcher_url = "/servlet/ScopeRequest_Result";
		request.getRequestDispatcher(dispatcher_url).forward(request, response);
		
		out.flush();
		out.close();
	}

}
