package com.mantou.common.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 * Created by wuweiliang on 2017/4/21.
 */
public class PasswordUtil {
    //调用命令行执行命令，返回命令行结果
    public static void exeCmd(String commandStr) {
        BufferedReader br = null;
        try {
            Process p = Runtime.getRuntime().exec(commandStr);
            br = new BufferedReader(new InputStreamReader(p.getInputStream(),"gbk"));
            String line = null;
            StringBuilder sb = new StringBuilder();
            while ((line = br.readLine()) != null) {
                sb.append(line + "\n");
            }
            System.out.println(sb.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally
        {
            if (br != null)
            {
                try {
                    br.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    //传入密码，输出bcrypt加密都的密文
    public static String bcrypt(String password){
        String command = "htpasswd -nbB -C 10 root " + password;
        exeCmd(command);
        return command;
    }
}
